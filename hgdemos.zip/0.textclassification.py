from transformers import pipeline

# Initialize the text classification pipeline
# This uses the default model "distilbert-base-uncased-finetuned-sst-2-english"
classifier = pipeline("sentiment-analysis")

# Classify some text
results = classifier("I hate using Hugging Face transformers!")
print(results)