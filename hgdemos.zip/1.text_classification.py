

from transformers import pipeline

# Specify the model explicitly
classifier = pipeline("sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english")

# Classify some text
results = classifier("I love using Hugging Face transformers!")
print(results)