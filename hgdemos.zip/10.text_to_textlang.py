from transformers import pipeline

# Initialize the text-to-text generation pipeline
text2text_generator = pipeline('text2text-generation', model='t5-small')

# Generate text
result = text2text_generator("translate English to German: Hugging Face is great!", max_length=40)
print(result)
