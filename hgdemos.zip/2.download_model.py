from transformers import AutoTokenizer, AutoModelForSequenceClassification

# Specify the model name
model_name = "distilbert-base-uncased-finetuned-sst-2-english"

# Download and load the model and tokenizer
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForSequenceClassification.from_pretrained(model_name)

# Save the model and tokenizer locally
model_dir = "./models/distilbert-base-uncased-finetuned-sst-2-english"
tokenizer.save_pretrained(model_dir)
model.save_pretrained(model_dir)

print(f"Model and tokenizer downloaded and saved to {model_dir}")