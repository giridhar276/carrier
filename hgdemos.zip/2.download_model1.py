from transformers import AutoTokenizer, AutoModelForSequenceClassification

# Specify the model name
model_name = "dslim/bert-base-NER"

# Download and load the model and tokenizer
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForSequenceClassification.from_pretrained(model_name)

# Save the model and tokenizer locally
model_dir = "./models/bert-base-NER"
tokenizer.save_pretrained(model_dir)
model.save_pretrained(model_dir)

print(f"Model and tokenizer downloaded and saved to {model_dir}")