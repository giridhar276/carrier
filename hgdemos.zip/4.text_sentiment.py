import warnings
from transformers import pipeline

# Suppress the NotOpenSSLWarning warning
warnings.filterwarnings("ignore", message="NotOpenSSLWarning")

# Initialize the sentiment-analysis pipeline with GPU support
classifier = pipeline('sentiment-analysis', model="./models/distilbert-base-uncased-finetuned-sst-2-english", device=0)

# Classify text
result = classifier("I love using Hugging Face transformers!")
print(result)
