from transformers import pipeline

# Initialize the named entity recognition pipeline
#ner = pipeline('ner', model='dbmdz/bert-large-cased-finetuned-conll03-english')
ner = pipeline('ner')

# Perform NER
result = ner("Google is a company based in New York City. Its headquarters are in DUMBO, therefore very close to the Manhattan Bridge.")
print(result)
