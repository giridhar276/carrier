from transformers import pipeline

# Initialize the question answering pipeline
question_answerer = pipeline('question-answering')

# Answer a question based on context
result = question_answerer(question="Where is Hugging Face based?", context="Hugging Face Inc. is a company based in New York City.")
print(result)