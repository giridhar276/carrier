import warnings
from transformers import pipeline
warnings.filterwarnings("ignore", message="NotOpenSSLWarning")
# Suppress other warnings


# Initialize the text generation pipeline
generator = pipeline('text-generation', model='gpt2',device=0)

# Generate text
result = generator("Once upon a time", max_length=50, num_return_sequences=1)
print(result)
