from transformers import pipeline

# Initialize the zero-shot classification pipeline
classifier = pipeline('zero-shot-classification', model='facebook/bart-large-mnli')

# Classify text into multiple labels
result = classifier(
    "Hugging Face is a company creating a lot of interesting tools.",
    candidate_labels=["technology", "education", "politics"],
)
print(result)
