import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import AIMessage
# Load environment variables from .env file
load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")

chat = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=api_key)

def faq_bot(question):
    response = chat.invoke(question)
    if isinstance(response, AIMessage):
        return response.content
    else:
        return "Unexpected response type."

# Example usage
question = "What are your business hours?"
print(faq_bot(question))
