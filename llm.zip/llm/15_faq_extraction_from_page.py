import os
import requests
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from bs4 import BeautifulSoup
from langchain_core.messages import AIMessage

# Load environment variables from .env file
load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")
chat = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=api_key)

def extract_faq(url, query):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    faq_text = soup.get_text()
    response = chat.invoke(f"{faq_text}\n{query}")
    return response.content

# Example usage
url = 'https://www.amazon.com/gp/help/customer/display.html?nodeId=508510'
query = "What is Amazon's return policy?"
print(extract_faq(url, query))
