import os
import requests
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from bs4 import BeautifulSoup
from langchain_core.messages import AIMessage

# Load environment variables from .env file
load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")
chat = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=api_key)

def parse_legal_document(url, query):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    legal_text = soup.get_text()
    response = chat.invoke(f"{legal_text}\n{query}")
    return response.content

# Example usage
url = 'https://www.google.com/intl/en/policies/privacy/'
query = "What are Google's policies regarding data privacy?"
print(parse_legal_document(url, query))
