import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import AIMessage
# Load environment variables from .env file
load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")

chat = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=api_key)

def virtual_assistant(task):
    response = chat.invoke(task)
    if isinstance(response, AIMessage):
        return response.content
    else:
        return "Unexpected response type."

# Example usage
task = "Set a reminder for a meeting at 3 PM."
print(virtual_assistant(task))
