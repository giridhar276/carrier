import os
import requests
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from bs4 import BeautifulSoup
from langchain_core.messages import AIMessage

# Load environment variables from .env file
load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")
chat = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=api_key)

def extract_menu_info(url, query):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    menu_info = soup.get_text()
    response = chat.invoke(f"{menu_info}\n{query}")
    return response.content

# Example usage
url = 'https://www.starbucks.com/menu'
query = "What are the prices of the main courses at Starbucks?"
print(extract_menu_info(url, query))
