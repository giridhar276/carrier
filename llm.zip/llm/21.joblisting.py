import os
import requests
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from bs4 import BeautifulSoup
from langchain_core.messages import AIMessage

# Load environment variables from .env file
load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")
chat = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=api_key)

def extract_job_listings(url, query):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    job_listings = soup.get_text()
    response = chat.invoke(f"{job_listings}\n{query}")
    return response.content

# Example usage
url = 'https://careers.google.com/jobs/results/'
query = "What are the job requirements for a software engineer position at Google?"
print(extract_job_listings(url, query))
