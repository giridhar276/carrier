import os
import requests
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from bs4 import BeautifulSoup
from langchain_core.messages import AIMessage

# Load environment variables from .env file
load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")
chat = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=api_key)

def parse_technical_docs(url, query):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    technical_docs = soup.get_text()
    response = chat.invoke(f"{technical_docs}\n{query}")
    return response.content

# Example usage
url = 'https://docs.python.org/3/tutorial/'
query = "Explain the installation process of Python."
print(parse_technical_docs(url, query))
