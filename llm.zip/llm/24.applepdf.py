import os
import requests
import pdfplumber
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import AIMessage

# Load environment variables from .env file
load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")
chat = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=api_key)

def download_pdf(url, file_path):
    response = requests.get(url)
    with open(file_path, 'wb') as file:
        file.write(response.content)

def extract_text_from_pdf(file_path):
    text = ""
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text()
    return text

def extract_product_info(file_path, query):
    product_info = extract_text_from_pdf(file_path)
    response = chat.invoke(f"{product_info}\n{query}")
    return response.content

# Example usage
url = 'https://manuals.info.apple.com/MANUALS/1000/MA1565/en_US/iphone_user_guide.pdf'
file_path = 'iphone_user_guide.pdf'

# Download the PDF
download_pdf(url, file_path)

# Query the PDF content
query = "What are the specifications of the iPhone?"
print(extract_product_info(file_path, query))
