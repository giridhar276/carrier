import os
import requests
import pdfplumber
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import AIMessage

# Load environment variables from .env file
load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")
chat = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=api_key)

def download_pdf(url, file_path):
    response = requests.get(url)
    with open(file_path, 'wb') as file:
        file.write(response.content)

def extract_text_from_pdf(file_path):
    text = ""
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text()
    return text

def summarize_content(file_path):
    page_text = extract_text_from_pdf(file_path)
    response = chat.invoke(f"Summarize the following content:\n{page_text}")
    return response.content

# Example usage
url = 'https://openknowledge.worldbank.org/bitstream/handle/10986/34639/9781464816406.pdf'
file_path = 'world_bank_annual_report.pdf'

# Download the PDF
download_pdf(url, file_path)

# Summarize the PDF content
print(summarize_content(file_path))
