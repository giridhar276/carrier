import os
import requests
import pdfplumber
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import AIMessage

# Load environment variables from .env file
load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")
chat = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=api_key)

def download_pdf(url, file_path):
    response = requests.get(url)
    with open(file_path, 'wb') as file:
        file.write(response.content)

def extract_text_from_pdf(file_path):
    text = ""
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text()
    return text

def extract_contact_info(file_path, query):
    contact_info = extract_text_from_pdf(file_path)
    response = chat.invoke(f"{contact_info}\n{query}")
    return response.content

# Example usage
url = 'https://www.un.org/sites/un2.un.org/files/un_system_contact_information.pdf'
file_path = 'un_contact_information.pdf'

# Download the PDF
download_pdf(url, file_path)

# Query the PDF content
query = "What is the contact information for the UN headquarters?"
print(extract_contact_info(file_path, query))
