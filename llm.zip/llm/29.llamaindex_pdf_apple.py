import os
import requests
import pdfplumber
import openai
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

openai.api_key = os.getenv("OPENAI_API_KEY")

def download_pdf(url, file_path):
    response = requests.get(url)
    with open(file_path, 'wb') as file:
        file.write(response.content)

def extract_text_from_pdf(file_path):
    text = ""
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text()
    return text

def query_openai(document_text, query):
    messages = [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": f"{document_text}\n\n{query}"}
    ]
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=messages,
        max_tokens=150
    )
    return response.choices[0].message['content'].strip()

# Example usage

# Download PDF
url = 'https://www.govinfo.gov/content/pkg/ERP-2008/pdf/ERP-2008-chapter4.pdf'
file_path = 'udhr.pdf'
download_pdf(url, file_path)

# Extract text from PDF
document_text = extract_text_from_pdf(file_path)

# Query the extracted text
query = "What are the key principles of the Universal Declaration of Human Rights?"
answer = query_openai(document_text, query)
print(answer)
