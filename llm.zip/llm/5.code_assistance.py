import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import AIMessage
# Load environment variables from .env file
load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")

chat = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=api_key)

def code_assistance(code_snippet):
    response = chat.invoke(f"Debug the following Python code: {code_snippet}")
    if isinstance(response, AIMessage):
        return response.content
    else:
        return "Unexpected response type."

# Example usage
code_snippet = "def add(a, b): return a + b"
print(code_assistance(code_snippet))
