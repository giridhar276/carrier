import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import AIMessage
# Load environment variables from .env file
load_dotenv()

api_key = os.getenv("OPENAI_API_KEY")

chat = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=api_key)

def mental_health_support(issue):
    response = chat.invoke(f"I am feeling {issue}. What should I do?")
    if isinstance(response, AIMessage):
        return response.content
    else:
        return "Unexpected response type."

# Example usage
issue = "anxious about my upcoming exams"
print(mental_health_support(issue))
